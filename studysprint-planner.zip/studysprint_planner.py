import os
import json
import sys
from datetime import datetime, date
import re

# Insert path for house style library if available
sys.path.insert(0, "/workspace/skill_scripts/data-craft")
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

try:
    import house
    from house import theme, color as C, fmt, annotate as A
    HAS_HOUSE = True
except Exception:
    HAS_HOUSE = False


class Task:
    """Dataclass representation of a StudySprint Task record."""
    def __init__(self, task_id, title, category, priority, deadline, estimated_hours, status="Pending", created_at=None):
        self.task_id = int(task_id)
        self.title = title.strip()
        self.category = category.strip().title()
        self.priority = priority.strip().capitalize()  # High, Medium, Low
        self.deadline = deadline.strip()  # YYYY-MM-DD
        self.estimated_hours = float(estimated_hours)
        self.status = status.strip().title()  # Pending, In Progress, Completed
        self.created_at = created_at or datetime.now().strftime("%Y-%m-%d %H:%M")

    def to_dict(self):
        return {
            "task_id": self.task_id,
            "title": self.title,
            "category": self.category,
            "priority": self.priority,
            "deadline": self.deadline,
            "estimated_hours": self.estimated_hours,
            "status": self.status,
            "created_at": self.created_at
        }

    @classmethod
    def from_dict(cls, data):
        return cls(
            task_id=data["task_id"],
            title=data["title"],
            category=data["category"],
            priority=data["priority"],
            deadline=data["deadline"],
            estimated_hours=data["estimated_hours"],
            status=data.get("status", "Pending"),
            created_at=data.get("created_at")
        )

    def is_overdue(self):
        if self.status == "Completed":
            return False
        try:
            deadline_date = datetime.strptime(self.deadline, "%Y-%m-%d").date()
            return deadline_date < date.today()
        except ValueError:
            return False


class StudySprintPlanner:
    """Core Manager Engine for StudySprint Planner."""
    def __init__(self, data_file="tasks.json"):
        self.data_file = data_file
        self.tasks = []
        self.next_id = 1
        self.load_tasks()

    def load_tasks(self):
        """Defensive loading of data with corrupted/missing file recovery."""
        if not os.path.exists(self.data_file):
            self.tasks = []
            self.save_tasks()
            return

        try:
            with open(self.data_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.tasks = [Task.from_dict(item) for item in data.get("tasks", [])]
                self.next_id = data.get("next_id", max([t.task_id for t in self.tasks], default=0) + 1)
        except (json.JSONDecodeError, KeyError, PermissionError, ValueError) as e:
            print(f"\n[!] Warning: Data file '{self.data_file}' was corrupted or invalid ({e}). Resetting to clean state.")
            self.tasks = []
            self.next_id = 1
            self.save_tasks()

    def save_tasks(self):
        """Persist current state to JSON file safely."""
        data = {
            "version": "1.0",
            "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "next_id": self.next_id,
            "tasks": [t.to_dict() for t in self.tasks]
        }
        temp_file = f"{self.data_file}.tmp"
        try:
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            os.replace(temp_file, self.data_file)
        except Exception as e:
            print(f"[!] Error saving data: {e}")

    def add_task(self, title, category, priority, deadline, estimated_hours, status="Pending"):
        """Add a new task record with validation."""
        task = Task(
            task_id=self.next_id,
            title=title,
            category=category,
            priority=priority,
            deadline=deadline,
            estimated_hours=estimated_hours,
            status=status
        )
        self.tasks.append(task)
        self.next_id += 1
        self.save_tasks()
        return task

    def search_tasks(self, keyword=None, category=None, status=None, priority=None):
        """Search and filter tasks based on multiple criteria."""
        results = self.tasks
        if keyword:
            kw = keyword.lower()
            results = [t for t in results if kw in t.title.lower() or kw in t.category.lower()]
        if category and category.lower() != "all":
            results = [t for t in results if t.category.lower() == category.lower()]
        if status and status.lower() != "all":
            results = [t for t in results if t.status.lower() == status.lower()]
        if priority and priority.lower() != "all":
            results = [t for t in results if t.priority.lower() == priority.lower()]
        return results

    def update_task_status(self, task_id, new_status):
        for t in self.tasks:
            if t.task_id == task_id:
                t.status = new_status.capitalize()
                self.save_tasks()
                return True
        return False

    def delete_task(self, task_id):
        initial_count = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.task_id != task_id]
        if len(self.tasks) < initial_count:
            self.save_tasks()
            return True
        return False

    def get_executive_summary(self):
        """Compute aggregated metrics, trends, and warning flags."""
        total = len(self.tasks)
        if total == 0:
            return {
                "total": 0, "completed": 0, "in_progress": 0, "pending": 0,
                "completion_rate": 0.0, "total_hours": 0.0, "completed_hours": 0.0,
                "overdue_count": 0, "category_breakdown": {}, "priority_breakdown": {}
            }

        completed = sum(1 for t in self.tasks if t.status == "Completed")
        in_prog = sum(1 for t in self.tasks if t.status == "In Progress")
        pending = sum(1 for t in self.tasks if t.status == "Pending")
        total_hours = sum(t.estimated_hours for t in self.tasks)
        completed_hours = sum(t.estimated_hours for t in self.tasks if t.status == "Completed")
        overdue = sum(1 for t in self.tasks if t.is_overdue())

        cat_breakdown = {}
        for t in self.tasks:
            cat_breakdown[t.category] = cat_breakdown.get(t.category, 0) + 1

        prio_breakdown = {"High": 0, "Medium": 0, "Low": 0}
        for t in self.tasks:
            prio_breakdown[t.priority] = prio_breakdown.get(t.priority, 0) + 1

        return {
            "total": total,
            "completed": completed,
            "in_progress": in_prog,
            "pending": pending,
            "completion_rate": round((completed / total) * 100, 1),
            "total_hours": round(total_hours, 1),
            "completed_hours": round(completed_hours, 1),
            "overdue_count": overdue,
            "category_breakdown": cat_breakdown,
            "priority_breakdown": prio_breakdown
        }

    def generate_chart(self, output_image_path="study_progress_chart.png"):
        """Generate executive visualization chart of study sprint progress."""
        if not HAS_MATPLOTLIB or len(self.tasks) == 0:
            return False

        summary = self.get_executive_summary()

        if HAS_HOUSE:
            theme.apply("report")
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5.5))

        # 1. Task Status Distribution
        statuses = ["Completed", "In Progress", "Pending"]
        counts = [summary["completed"], summary["in_progress"], summary["pending"]]
        colors = ["#009e73", "#e69f00", "#56b4e9"]

        bars = ax1.bar(statuses, counts, color=colors, width=0.55)
        ax1.set_ylabel("Number of Tasks", fontsize=11, fontweight='bold')
        ax1.set_title("Status Breakdown", fontsize=12, fontweight='bold', pad=10)
        for bar in bars:
            yval = bar.get_height()
            if yval > 0:
                ax1.text(bar.get_x() + bar.get_width()/2.0, yval + 0.3, f"{int(yval)}", ha='center', va='bottom', fontweight='bold')

        # Add Overdue indicator text if any
        if summary["overdue_count"] > 0:
            ax1.text(0.5, 0.9, f"⚠️ {summary['overdue_count']} Overdue Task(s)", transform=ax1.transAxes,
                     ha='center', color='#d55e00', fontweight='bold', bbox=dict(boxstyle='round,pad=0.3', facecolor='#fee8e6', edgecolor='#d55e00'))

        # 2. Category Breakdown (Horizontal Bar)
        cats = list(summary["category_breakdown"].keys())
        cat_counts = list(summary["category_breakdown"].values())
        
        ax2.barh(cats, cat_counts, color="#0072b2", height=0.55)
        ax2.set_xlabel("Task Count", fontsize=11, fontweight='bold')
        ax2.set_title("Tasks by Category", fontsize=12, fontweight='bold', pad=10)
        for i, v in enumerate(cat_counts):
            ax2.text(v + 0.2, i, str(v), va='center', fontweight='bold')

        if HAS_HOUSE:
            theme.title(fig, f"StudySprint Overview: {summary['completion_rate']}% Completion Rate Across {summary['total']} Tasks",
                        f"Total Workload: {summary['total_hours']} Hours | Completed: {summary['completed_hours']} Hours")
            theme.declutter(ax1)
            theme.declutter(ax2)
            theme.source(fig, "Source: StudySprint Planner Local Database (tasks.json)")
            house.save(fig, output_image_path)
        else:
            fig.suptitle(f"StudySprint Progress Dashboard ({summary['completion_rate']}% Completed)", fontsize=14, fontweight='bold')
            plt.tight_layout()
            plt.savefig(output_image_path, dpi=200, bbox_inches='tight')

        plt.close(fig)
        return True


# Input Validation Utilities
def get_valid_input(prompt, validator, error_msg):
    while True:
        val = input(prompt).strip()
        if validator(val):
            return val
        print(f"  [!] {error_msg}")


def validate_date(date_str):
    if not date_str:
        return False
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def validate_positive_float(val_str):
    try:
        v = float(val_str)
        return v > 0
    except ValueError:
        return False


def print_menu():
    print("\n" + "="*50)
    print("      🚀 STUDYSPRINT PLANNER - CLI MENU")
    print("="*50)
    print("  1. 📋 View All Study Tasks")
    print("  2. ➕ Add New Study Task")
    print("  3. 🔄 Update Task Status")
    print("  4. 🔍 Search & Filter Tasks")
    print("  5. ❌ Delete Task")
    print("  6. 📊 Executive Summary & Dashboard")
    print("  7. 📈 Export Visual Progress Chart")
    print("  8. 🚪 Exit")
    print("="*50)


def display_task_table(tasks):
    if not tasks:
        print("\n  [i] No tasks found matching criteria.")
        return

    print(f"\n{'ID':<5} | {'Title':<30} | {'Category':<15} | {'Priority':<8} | {'Deadline':<10} | {'Hours':<6} | {'Status':<12}")
    print("-" * 105)
    for t in tasks:
        overdue_flag = " ⚠️" if t.is_overdue() else ""
        print(f"{t.task_id:<5} | {t.title[:28]:<30} | {t.category[:13]:<15} | {t.priority:<8} | {t.deadline:<10} | {t.estimated_hours:<6.1f} | {t.status + overdue_flag:<12}")
    print("-" * 105)


def run_cli():
    planner = StudySprintPlanner("tasks.json")

    print("\nWelcome to StudySprint Planner - Your Local Study Productivity Suite!")
    
    while True:
        print_menu()
        choice = input("Select an option (1-8): ").strip()

        if choice == "1":
            display_task_table(planner.tasks)

        elif choice == "2":
            print("\n--- Add New Task ---")
            title = get_valid_input("Task Title: ", lambda s: len(s) >= 2, "Title must be at least 2 characters.")
            category = get_valid_input("Category (e.g. Computer Science, Math, Physics): ", lambda s: len(s) >= 2, "Category required.")
            priority = get_valid_input("Priority (High/Medium/Low): ", lambda s: s.capitalize() in ["High", "Medium", "Low"], "Choose High, Medium, or Low.")
            deadline = get_valid_input("Deadline (YYYY-MM-DD): ", validate_date, "Enter a valid date in YYYY-MM-DD format.")
            hours = float(get_valid_input("Estimated Hours (e.g. 2.5): ", validate_positive_float, "Must be a positive number."))
            status = get_valid_input("Initial Status (Pending/In Progress/Completed) [default Pending]: ",
                                     lambda s: s == "" or s.title() in ["Pending", "In Progress", "Completed"],
                                     "Choose Pending, In Progress, or Completed.")
            if not status:
                status = "Pending"

            task = planner.add_task(title, category, priority, deadline, hours, status)
            print(f"\n✅ Task #{task.task_id} '{task.title}' added successfully!")

        elif choice == "3":
            print("\n--- Update Task Status ---")
            display_task_table(planner.tasks)
            if not planner.tasks:
                continue
            task_id_str = get_valid_input("Enter Task ID to update: ", lambda s: s.isdigit(), "Must be numeric ID.")
            task_id = int(task_id_str)
            new_status = get_valid_input("New Status (Pending/In Progress/Completed): ",
                                         lambda s: s.title() in ["Pending", "In Progress", "Completed"],
                                         "Choose Pending, In Progress, or Completed.")
            if planner.update_task_status(task_id, new_status.title()):
                print(f"\n✅ Task #{task_id} updated to '{new_status.title()}'!")
            else:
                print(f"\n[!] Task #{task_id} not found.")

        elif choice == "4":
            print("\n--- Search & Filter Tasks ---")
            kw = input("Keyword search (press Enter to skip): ").strip()
            cat = input("Filter by Category (press Enter to skip): ").strip() or "all"
            status = input("Filter by Status (Pending/In Progress/Completed, press Enter to skip): ").strip() or "all"
            prio = input("Filter by Priority (High/Medium/Low, press Enter to skip): ").strip() or "all"

            results = planner.search_tasks(keyword=kw, category=cat, status=status, priority=prio)
            display_task_table(results)

        elif choice == "5":
            print("\n--- Delete Task ---")
            display_task_table(planner.tasks)
            if not planner.tasks:
                continue
            task_id_str = get_valid_input("Enter Task ID to delete: ", lambda s: s.isdigit(), "Must be numeric ID.")
            task_id = int(task_id_str)
            if planner.delete_task(task_id):
                print(f"\n✅ Task #{task_id} deleted successfully.")
            else:
                print(f"\n[!] Task #{task_id} not found.")

        elif choice == "6":
            print("\n--- Executive Summary Dashboard ---")
            s = planner.get_executive_summary()
            print(f"\nTotal Tasks Tracked : {s['total']}")
            print(f"Completed Tasks     : {s['completed']} ({s['completion_rate']}%)")
            print(f"In Progress Tasks   : {s['in_progress']}")
            print(f"Pending Tasks       : {s['pending']}")
            print(f"Total Workload      : {s['total_hours']} hrs (Completed: {s['completed_hours']} hrs)")
            print(f"Overdue Warnings    : {s['overdue_count']} task(s) ⚠️")

            print("\nPriority Distribution:")
            for p, count in s['priority_breakdown'].items():
                print(f"  - {p:<8}: {count}")

            print("\nCategory Distribution:")
            for c, count in s['category_breakdown'].items():
                print(f"  - {c:<18}: {count}")

        elif choice == "7":
            print("\n--- Exporting Visual Progress Chart ---")
            img_path = "study_progress_chart.png"
            if planner.generate_chart(img_path):
                print(f"✅ Progress chart exported successfully to '{img_path}'!")
            else:
                print("[!] Chart generation failed or matplotlib unavailable.")

        elif choice == "8":
            print("\nThank you for using StudySprint Planner! Good luck with your studies!\n")
            break
        else:
            print("Invalid choice, please select 1-8.")


if __name__ == "__main__":
    run_cli()
