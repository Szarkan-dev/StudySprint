import unittest
import os
import sys
import json
import tempfile

# Ensure scratch path is in sys.path
sys.path.insert(0, "/workspace/scratch")

from studysprint_planner import Task, TaskRepository, StudySprintService


class TestStudySprintPlanner(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.data_file = os.path.join(self.temp_dir.name, "test_tasks.json")
        self.repo = TaskRepository(data_file=self.data_file)
        self.service = StudySprintService(repository=self.repo)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_task_creation_and_eisenhower(self):
        task = Task(1, "Study Calculus", "Math", "High", "2026-11-20", 3.0, "Pending")
        self.assertEqual(task.task_id, 1)
        self.assertEqual(task.title, "Study Calculus")
        self.assertEqual(task.category, "Math")
        self.assertEqual(task.priority, "High")
        self.assertEqual(task.status, "Pending")
        self.assertIn("Q1", task.eisenhower_quadrant)

    def test_atomic_save_and_load(self):
        self.service.add_task("Physics HW", "Physics", "Medium", "2026-12-01", 2.0)
        self.assertEqual(len(self.service.tasks), 1)

        # Reload from same file
        new_service = StudySprintService(repository=self.repo)
        self.assertEqual(len(new_service.tasks), 1)
        self.assertEqual(new_service.tasks[0].title, "Physics HW")

    def test_corrupted_json_recovery(self):
        # Write corrupted content to data file
        with open(self.data_file, 'w') as f:
            f.write("{invalid_json_content...")

        # Service should recover gracefully without crashing
        recovered_service = StudySprintService(repository=self.repo)
        self.assertEqual(len(recovered_service.tasks), 0)

    def test_crud_operations(self):
        t1 = self.service.add_task("Task 1", "CS", "High", "2026-12-01", 1.0)
        t2 = self.service.add_task("Task 2", "Math", "Low", "2026-12-02", 2.0)

        self.assertEqual(len(self.service.tasks), 2)

        # Update
        updated = self.service.update_task(t1.task_id, status="Completed", priority="Low")
        self.assertIsNotNone(updated)
        self.assertEqual(updated.status, "Completed")
        self.assertEqual(updated.priority, "Low")

        # Delete
        deleted = self.service.delete_task(t2.task_id)
        self.assertTrue(deleted)
        self.assertEqual(len(self.service.tasks), 1)

    def test_search(self):
        self.service.add_task("Data Structures Tree", "CS", "High", "2026-12-01", 2.0)
        self.service.add_task("Organic Chemistry", "Chemistry", "Medium", "2026-12-02", 3.0)

        results = self.service.search_tasks("tree")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].category, "Cs")

    def test_pagination(self):
        for i in range(25):
            self.service.add_task(f"Task {i}", "Test", "Low", "2026-12-10", 1.0)

        tasks_p1, total, total_pages = self.service.list_tasks(page=1, page_size=10)
        self.assertEqual(len(tasks_p1), 10)
        self.assertEqual(total, 25)
        self.assertEqual(total_pages, 3)

        tasks_p3, _, _ = self.service.list_tasks(page=3, page_size=10)
        self.assertEqual(len(tasks_p3), 5)

    def test_summary_analytics(self):
        self.service.add_task("T1", "CS", "High", "2026-12-01", 2.0, "Completed")
        self.service.add_task("T2", "CS", "Low", "2026-12-02", 4.0, "Pending")

        stats = self.service.get_summary_analytics()
        self.assertEqual(stats["total"], 2)
        self.assertEqual(stats["completed"], 1)
        self.assertEqual(stats["completion_rate"], 50.0)
        self.assertEqual(stats["total_hours"], 6.0)

    def test_markdown_and_csv_export(self):
        self.service.add_task("Export Test", "General", "High", "2026-12-05", 1.5)
        
        md_path = os.path.join(self.temp_dir.name, "report.md")
        csv_path = os.path.join(self.temp_dir.name, "export.csv")

        self.assertTrue(self.service.export_markdown_report(md_path))
        self.assertTrue(self.service.export_csv(csv_path))

        self.assertTrue(os.path.exists(md_path))
        self.assertTrue(os.path.exists(csv_path))

    def test_csv_import(self):
        csv_path = os.path.join(self.temp_dir.name, "import.csv")
        with open(csv_path, 'w') as f:
            f.write("task_id,title,category,priority,deadline,estimated_hours,status\n")
            f.write("100,Imported Task 1,History,High,2026-12-10,3.0,Pending\n")
            f.write("101,Imported Task 2,Art,Low,2026-12-11,2.0,Completed\n")

        imported_count = self.service.import_csv(csv_path)
        self.assertEqual(imported_count, 2)
        self.assertEqual(len(self.service.tasks), 2)


if __name__ == "__main__":
    unittest.main()
