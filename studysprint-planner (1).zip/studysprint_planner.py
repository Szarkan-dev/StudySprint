import os
import json
import sys
import csv
import logging
import tempfile
from datetime import datetime, date
from typing import List, Dict, Any, Optional, Tuple

# Set up structured logging
LOG_FILE = "studysprint.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger("StudySprintPlanner")

# Headless matplotlib configuration for charts
sys.path.insert(0, "/workspace/skill_scripts/data-craft")
try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False

try:
    import house
    from house import theme, color as C, fmt, annotate as A
    HAS_HOUSE = True
except Exception:
    HAS_HOUSE = False


class Task:
    """Domain model representing a StudySprint academic task."""
    VALID_PRIORITIES = {"High", "Medium", "Low"}
    VALID_STATUSES = {"Pending", "In Progress", "Completed"}

    def __init__(
        self,
        task_id: int,
        title: str,
        category: str,
        priority: str,
        deadline: str,
        estimated_hours: float,
        status: str = "Pending",
        created_at: Optional[str] = None
    ):
        self.task_id = int(task_id)
        self.title = title.strip()
        self.category = category.strip().title()
        
        norm_priority = priority.strip().capitalize()
        self.priority = norm_priority if norm_priority in self.VALID_PRIORITIES else "Medium"
        
        self.deadline = deadline.strip()
        self.estimated_hours = max(0.1, float(estimated_hours))
        
        norm_status = status.strip().title()
        self.status = norm_status if norm_status in self.VALID_STATUSES else "Pending"
        
        self.created_at = created_at or datetime.now().strftime("%Y-%m-%d %H:%M")

    @property
    def eisenhower_quadrant(self) -> str:
        """Categorize task into Eisenhower Matrix quadrant based on priority & urgency."""
        is_urgent = self.is_overdue() or self.days_until_deadline() <= 3
        is_important = self.priority in {"High", "Medium"}

        if is_urgent and is_important:
            return "Q1: Do First (Urgent & Important)"
        elif not is_urgent and is_important:
            return "Q2: Schedule (Important, Not Urgent)"
        elif is_urgent and not is_important:
            return "Q3: Delegate/Quick (Urgent, Not Important)"
        else:
            return "Q4: Don't Do / Backlog (Neither)"

    def days_until_deadline(self) -> int:
        try:
            deadline_date = datetime.strptime(self.deadline, "%Y-%m-%d").date()
            return (deadline_date - date.today()).days
        except ValueError:
            return 999

    def is_overdue(self) -> bool:
        if self.status == "Completed":
            return False
        try:
            deadline_date = datetime.strptime(self.deadline, "%Y-%m-%d").date()
            return deadline_date < date.today()
        except ValueError:
            return False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "title": self.title,
            "category": self.category,
            "priority": self.priority,
            "deadline": self.deadline,
            "estimated_hours": self.estimated_hours,
            "status": self.status,
            "created_at": self.created_at
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Task":
        return cls(
            task_id=data["task_id"],
            title=data["title"],
            category=data["category"],
            priority=data["priority"],
            deadline=data["deadline"],
            estimated_hours=data["estimated_hours"],
            status=data.get("status", "Pending"),
            created_at=data.get("created_at")
        )


class TaskRepository:
    """Thread-safe and crash-resilient repository for Task persistence."""
    def __init__(self, data_file: str = "tasks.json"):
        self.data_file = data_file

    def load_all(self) -> Tuple[List[Task], int]:
        """Loads tasks safely from JSON file. Recovers gracefully if file is corrupted."""
        if not os.path.exists(self.data_file):
            logger.info(f"Data file '{self.data_file}' not found. Initializing empty dataset.")
            return [], 1

        try:
            with open(self.data_file, 'r', encoding='utf-8') as f:
                content = f.read().strip()
                if not content:
                    return [], 1
                data = json.loads(content)
                tasks = [Task.from_dict(item) for item in data.get("tasks", [])]
                next_id = data.get("next_id", max([t.task_id for t in tasks], default=0) + 1)
                logger.info(f"Loaded {len(tasks)} tasks successfully from '{self.data_file}'.")
                return tasks, next_id
        except Exception as e:
            logger.warning(f"Failed to parse '{self.data_file}': {e}. Creating backup and starting fresh.")
            backup_file = f"{self.data_file}.bak_{int(datetime.now().timestamp())}"
            try:
                if os.path.exists(self.data_file):
                    os.rename(self.data_file, backup_file)
            except Exception:
                pass
            return [], 1

    def save_all(self, tasks: List[Task], next_id: int) -> bool:
        """Atomic write using temporary file to prevent file corruption during crashes."""
        data = {
            "version": "2.0",
            "last_updated": datetime.now().isoformat(),
            "next_id": next_id,
            "tasks": [t.to_dict() for t in tasks]
        }
        dir_name = os.path.dirname(os.path.abspath(self.data_file))
        try:
            with tempfile.NamedTemporaryFile('w', dir=dir_name, delete=False, encoding='utf-8') as tf:
                json.dump(data, tf, indent=2)
                temp_path = tf.name
            os.replace(temp_path, self.data_file)
            logger.info(f"Successfully saved {len(tasks)} tasks to '{self.data_file}'.")
            return True
        except Exception as e:
            logger.error(f"Error saving tasks to '{self.data_file}': {e}")
            return False


class StudySprintService:
    """Decoupled Business Engine implementing search, pagination, analytics & reporting."""
    def __init__(self, repository: Optional[TaskRepository] = None):
        self.repo = repository or TaskRepository()
        self.tasks: List[Task] = []
        self.next_id: int = 1
        self.reload()

    def reload(self):
        self.tasks, self.next_id = self.repo.load_all()

    def _save(self) -> bool:
        return self.repo.save_all(self.tasks, self.next_id)

    def add_task(self, title: str, category: str, priority: str, deadline: str, estimated_hours: float, status: str = "Pending") -> Task:
        task = Task(
            task_id=self.next_id,
            title=title,
            category=category,
            priority=priority,
            deadline=deadline,
            estimated_hours=estimated_hours,
            status=status
        )
        self.tasks.append(task)
        self.next_id += 1
        self._save()
        logger.info(f"Added Task ID {task.task_id}: '{task.title}'")
        return task

    def update_task(self, task_id: int, **kwargs) -> Optional[Task]:
        task = self.get_task(task_id)
        if not task:
            return None
        
        for key, val in kwargs.items():
            if val is not None and hasattr(task, key):
                if key == "category":
                    setattr(task, key, str(val).strip().title())
                elif key == "priority":
                    norm = str(val).strip().capitalize()
                    if norm in Task.VALID_PRIORITIES:
                        setattr(task, key, norm)
                elif key == "status":
                    norm = str(val).strip().title()
                    if norm in Task.VALID_STATUSES:
                        setattr(task, key, norm)
                elif key == "estimated_hours":
                    setattr(task, key, max(0.1, float(val)))
                elif key == "title":
                    setattr(task, key, str(val).strip())
                elif key == "deadline":
                    setattr(task, key, str(val).strip())

        self._save()
        logger.info(f"Updated Task ID {task_id}")
        return task

    def delete_task(self, task_id: int) -> bool:
        initial_len = len(self.tasks)
        self.tasks = [t for t in self.tasks if t.task_id != task_id]
        if len(self.tasks) < initial_len:
            self._save()
            logger.info(f"Deleted Task ID {task_id}")
            return True
        return False

    def get_task(self, task_id: int) -> Optional[Task]:
        for t in self.tasks:
            if t.task_id == task_id:
                return t
        return None

    def list_tasks(
        self,
        status: Optional[str] = None,
        category: Optional[str] = None,
        priority: Optional[str] = None,
        sort_by: Optional[str] = "deadline",
        page: int = 1,
        page_size: int = 10
    ) -> Tuple[List[Task], int, int]:
        """Supports multi-attribute filtering, sorting, and pagination."""
        filtered = self.tasks

        if status:
            filtered = [t for t in filtered if t.status.lower() == status.lower()]
        if category:
            filtered = [t for t in filtered if t.category.lower() == category.lower()]
        if priority:
            filtered = [t for t in filtered if t.priority.lower() == priority.lower()]

        if sort_by == "deadline":
            filtered = sorted(filtered, key=lambda x: x.deadline)
        elif sort_by == "priority":
            prio_order = {"High": 1, "Medium": 2, "Low": 3}
            filtered = sorted(filtered, key=lambda x: prio_order.get(x.priority, 4))
        elif sort_by == "hours":
            filtered = sorted(filtered, key=lambda x: x.estimated_hours, reverse=True)
        elif sort_by == "id":
            filtered = sorted(filtered, key=lambda x: x.task_id)

        total_count = len(filtered)
        total_pages = max(1, (total_count + page_size - 1) // page_size)
        
        page = max(1, min(page, total_pages))
        start_idx = (page - 1) * page_size
        end_idx = start_idx + page_size

        return filtered[start_idx:end_idx], total_count, total_pages

    def search_tasks(self, query: str) -> List[Task]:
        q = query.lower().strip()
        if not q:
            return self.tasks
        return [
            t for t in self.tasks
            if q in t.title.lower() or q in t.category.lower() or q in t.priority.lower() or q in t.status.lower()
        ]

    def get_summary_analytics(self) -> Dict[str, Any]:
        total = len(self.tasks)
        if total == 0:
            return {
                "total": 0, "completed": 0, "in_progress": 0, "pending": 0,
                "completion_rate": 0.0, "total_hours": 0.0, "completed_hours": 0.0,
                "overdue_count": 0, "categories": {}, "priorities": {}, "eisenhower": {}
            }

        completed = sum(1 for t in self.tasks if t.status == "Completed")
        in_progress = sum(1 for t in self.tasks if t.status == "In Progress")
        pending = sum(1 for t in self.tasks if t.status == "Pending")
        overdue = sum(1 for t in self.tasks if t.is_overdue())

        total_hours = sum(t.estimated_hours for t in self.tasks)
        completed_hours = sum(t.estimated_hours for t in self.tasks if t.status == "Completed")

        cat_counts = {}
        for t in self.tasks:
            cat_counts[t.category] = cat_counts.get(t.category, 0) + 1

        prio_counts = {"High": 0, "Medium": 0, "Low": 0}
        for t in self.tasks:
            prio_counts[t.priority] = prio_counts.get(t.priority, 0) + 1

        eisen_counts = {}
        for t in self.tasks:
            q_name = t.eisenhower_quadrant
            eisen_counts[q_name] = eisen_counts.get(q_name, 0) + 1

        return {
            "total": total,
            "completed": completed,
            "in_progress": in_progress,
            "pending": pending,
            "completion_rate": round((completed / total) * 100, 1),
            "total_hours": round(total_hours, 1),
            "completed_hours": round(completed_hours, 1),
            "overdue_count": overdue,
            "categories": cat_counts,
            "priorities": prio_counts,
            "eisenhower": eisen_counts
        }

    def export_markdown_report(self, filepath: str = "study_report.md") -> bool:
        stats = self.get_summary_analytics()
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        md_content = f"""# 📚 StudySprint Planner — Executive Progress & Audit Report
*Generated on {now_str}*

---

## 📊 Summary Analytics

| Metric | Value | Details |
| :--- | :--- | :--- |
| **Total Tasks** | `{stats['total']}` | Active Sprint Scope |
| **Completed Tasks** | `{stats['completed']}` | `{stats['completion_rate']}%` Completion Rate |
| **In Progress** | `{stats['in_progress']}` | Active Workstreams |
| **Pending** | `{stats['pending']}` | Backlog Items |
| **Overdue Tasks** | `{stats['overdue_count']}` | ⚠️ Requires Immediate Focus |
| **Total Workload** | `{stats['total_hours']} hrs` | `{stats['completed_hours']} hrs` Logged Completed |

---

## 🎯 Priority & Category Breakdown

### Priorities
"""
        for p, count in stats['priorities'].items():
            pct = round((count / stats['total']) * 100, 1) if stats['total'] > 0 else 0
            md_content += f"- **{p} Priority**: {count} tasks ({pct}%)\n"

        md_content += "\n### Subject Categories\n"
        for c, count in stats['categories'].items():
            pct = round((count / stats['total']) * 100, 1) if stats['total'] > 0 else 0
            md_content += f"- **{c}**: {count} tasks ({pct}%)\n"

        md_content += "\n---\n\n## 📝 Detailed Task Roster\n\n"
        md_content += "| ID | Title | Category | Priority | Deadline | Hours | Status | Overdue |\n"
        md_content += "|---|---|---|---|---|---|---|---|\n"

        for t in sorted(self.tasks, key=lambda x: x.deadline):
            overdue_flag = "🚨 YES" if t.is_overdue() else "OK"
            md_content += f"| {t.task_id} | {t.title} | {t.category} | {t.priority} | {t.deadline} | {t.estimated_hours} | {t.status} | {overdue_flag} |\n"

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(md_content)
            logger.info(f"Exported Markdown report to '{filepath}'.")
            return True
        except Exception as e:
            logger.error(f"Failed to write Markdown report: {e}")
            return False

    def export_csv(self, filepath: str = "study_export.csv") -> bool:
        try:
            with open(filepath, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(["task_id", "title", "category", "priority", "deadline", "estimated_hours", "status", "created_at"])
                for t in self.tasks:
                    writer.writerow([t.task_id, t.title, t.category, t.priority, t.deadline, t.estimated_hours, t.status, t.created_at])
            logger.info(f"Exported CSV data to '{filepath}'.")
            return True
        except Exception as e:
            logger.error(f"Failed to export CSV: {e}")
            return False

    def import_csv(self, filepath: str) -> int:
        if not os.path.exists(filepath):
            logger.error(f"CSV file '{filepath}' not found.")
            return 0

        imported_count = 0
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    try:
                        self.add_task(
                            title=row["title"],
                            category=row["category"],
                            priority=row["priority"],
                            deadline=row["deadline"],
                            estimated_hours=float(row["estimated_hours"]),
                            status=row.get("status", "Pending")
                        )
                        imported_count += 1
                    except (KeyError, ValueError) as err:
                        logger.warning(f"Skipping invalid CSV row {row}: {err}")
            logger.info(f"Successfully imported {imported_count} tasks from '{filepath}'.")
            return imported_count
        except Exception as e:
            logger.error(f"Failed to read CSV import file: {e}")
            return 0

    def generate_chart(self, filepath: str = "study_progress_chart.png") -> bool:
        if not HAS_MATPLOTLIB:
            logger.warning("Matplotlib is not installed. Skipping chart generation.")
            return False

        stats = self.get_summary_analytics()
        if stats['total'] == 0:
            logger.warning("No tasks available to generate chart.")
            return False

        try:
            if HAS_HOUSE:
                theme.apply("report")
            
            fig, axes = plt.subplots(2, 2, figsize=(14, 10))

            # Subplot 1: Status Distribution (Donut Chart)
            statuses = ["Completed", "In Progress", "Pending"]
            status_counts = [stats["completed"], stats["in_progress"], stats["pending"]]
            colors = ["#009e73", "#e69f00", "#d55e00"]
            
            axes[0, 0].pie(
                status_counts,
                labels=statuses,
                autopct="%1.1f%%",
                startangle=140,
                colors=colors,
                wedgeprops=dict(width=0.4, edgecolor='white')
            )
            axes[0, 0].set_title("Task Status Distribution", fontsize=12, fontweight='bold')

            # Subplot 2: Priority Breakdown (Bar Chart)
            prios = list(stats["priorities"].keys())
            p_counts = list(stats["priorities"].values())
            p_colors = ["#d55e00", "#e69f00", "#0072b2"]
            axes[0, 1].bar(prios, p_counts, color=p_colors)
            axes[0, 1].set_title("Tasks by Priority Level", fontsize=12, fontweight='bold')
            axes[0, 1].set_ylabel("Task Count")
            for i, v in enumerate(p_counts):
                axes[0, 1].text(i, v + 0.2, str(v), ha='center', fontweight='bold')

            # Subplot 3: Workload Hours by Category (Horizontal Bar Chart)
            cats = list(stats["categories"].keys())
            c_counts = list(stats["categories"].values())
            axes[1, 0].barh(cats, c_counts, color="#0072b2")
            axes[1, 0].set_title("Task Volume by Subject Category", fontsize=12, fontweight='bold')
            axes[1, 0].set_xlabel("Task Count")

            # Subplot 4: Eisenhower Matrix Quadrants
            quads = ["Q1: Do First", "Q2: Schedule", "Q3: Quick", "Q4: Backlog"]
            quad_keys = [
                "Q1: Do First (Urgent & Important)",
                "Q2: Schedule (Important, Not Urgent)",
                "Q3: Delegate/Quick (Urgent, Not Important)",
                "Q4: Don't Do / Backlog (Neither)"
            ]
            q_values = [stats["eisenhower"].get(qk, 0) for qk in quad_keys]
            axes[1, 1].bar(quads, q_values, color="#cc79a7")
            axes[1, 1].set_title("Eisenhower Urgency/Importance Matrix", fontsize=12, fontweight='bold')
            axes[1, 1].set_ylabel("Task Count")
            for i, v in enumerate(q_values):
                axes[1, 1].text(i, v + 0.1, str(v), ha='center', fontweight='bold')

            if HAS_HOUSE:
                theme.title(fig, f"StudySprint Workload & Completion Overview ({stats['completion_rate']}% Complete)",
                            f"Total Tasks: {stats['total']} | Total Hours: {stats['total_hours']}h | Overdue: {stats['overdue_count']}")
                theme.source(fig, "Source: StudySprint Planner Task Repository")
                house.save(fig, filepath)
            else:
                plt.suptitle(f"StudySprint Workload & Completion Overview ({stats['completion_rate']}% Complete)", fontsize=14, fontweight='bold')
                plt.tight_layout()
                plt.savefig(filepath, dpi=200, bbox_inches='tight')
                plt.close(fig)

            logger.info(f"Saved visual progress dashboard chart to '{filepath}'.")
            return True
        except Exception as e:
            logger.error(f"Failed to render progress chart: {e}")
            return False


class CLIView:
    """Terminal Presentation Layer with input validation & pagination."""
    def __init__(self, service: StudySprintService):
        self.service = service

    def print_banner(self):
        print("\n" + "=" * 65)
        print("    🎓 STUDYSPRINT PLANNER — TASK & DEADLINE MANAGEMENT")
        print("=" * 65)

    def prompt_string(self, prompt: str, default: Optional[str] = None) -> str:
        while True:
            val = input(f"{prompt} [{default}]: " if default else f"{prompt}: ").strip()
            if not val and default is not None:
                return default
            if val:
                return val
            print("   ❌ Input cannot be empty. Please try again.")

    def prompt_date(self, prompt: str, default: Optional[str] = None) -> str:
        while True:
            val = input(f"{prompt} (YYYY-MM-DD) [{default}]: " if default else f"{prompt} (YYYY-MM-DD): ").strip()
            if not val and default:
                return default
            try:
                dt = datetime.strptime(val, "%Y-%m-%d").date()
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                print("   ❌ Invalid date format. Please use YYYY-MM-DD (e.g. 2026-12-15).")

    def prompt_choice(self, prompt: str, choices: List[str], default: Optional[str] = None) -> str:
        normalized_choices = [c.capitalize() for c in choices]
        choices_str = "/".join(normalized_choices)
        while True:
            val = input(f"{prompt} ({choices_str}) [{default}]: " if default else f"{prompt} ({choices_str}): ").strip()
            if not val and default:
                return default.capitalize()
            if val.capitalize() in normalized_choices:
                return val.capitalize()
            print(f"   ❌ Invalid choice. Must be one of: {choices_str}")

    def prompt_float(self, prompt: str, default: Optional[float] = None) -> float:
        while True:
            val = input(f"{prompt} [{default}]: " if default is not None else f"{prompt}: ").strip()
            if not val and default is not None:
                return default
            try:
                num = float(val)
                if num <= 0:
                    print("   ❌ Number must be greater than zero.")
                    continue
                return num
            except ValueError:
                print("   ❌ Invalid number format. Please enter a valid decimal number.")

    def prompt_int(self, prompt: str) -> int:
        while True:
            val = input(f"{prompt}: ").strip()
            try:
                return int(val)
            except ValueError:
                print("   ❌ Invalid integer. Please enter a whole number.")

    def display_task_table(self, tasks: List[Task], page: int, total_pages: int, total_count: int):
        print(f"\n📋 Task Roster (Page {page} of {total_pages} | Total: {total_count})")
        print("-" * 105)
        print(f"{'ID':<4} | {'Title':<30} | {'Category':<14} | {'Priority':<8} | {'Deadline':<10} | {'Hours':<5} | {'Status':<11} | {'Alert'}")
        print("-" * 105)
        if not tasks:
            print("  (No tasks found matching current filter/page)")
        for t in tasks:
            alert = "🚨 OVERDUE" if t.is_overdue() else ("⏳ Soon" if t.days_until_deadline() <= 3 and t.status != "Completed" else "OK")
            title_trunc = t.title[:28] + ".." if len(t.title) > 30 else t.title
            print(f"{t.task_id:<4} | {title_trunc:<30} | {t.category:<14} | {t.priority:<8} | {t.deadline:<10} | {t.estimated_hours:<5.1f} | {t.status:<11} | {alert}")
        print("-" * 105)

    def menu_add_task(self):
        print("\n➕ Add New Study Task")
        title = self.prompt_string("Task Title")
        category = self.prompt_string("Category / Subject", default="General")
        priority = self.prompt_choice("Priority Level", ["High", "Medium", "Low"], default="Medium")
        deadline = self.prompt_date("Target Deadline")
        hours = self.prompt_float("Estimated Effort (Hours)", default=2.0)
        status = self.prompt_choice("Initial Status", ["Pending", "In Progress", "Completed"], default="Pending")

        task = self.service.add_task(title, category, priority, deadline, hours, status)
        print(f"\n✅ Task #{task.task_id} successfully created!")

    def menu_list_tasks(self):
        page = 1
        page_size = 10
        sort_by = "deadline"

        while True:
            tasks, total_count, total_pages = self.service.list_tasks(sort_by=sort_by, page=page, page_size=page_size)
            self.display_task_table(tasks, page, total_pages, total_count)
            print("\nNavigation: [N]ext Page | [P]rev Page | [S]ort Option | [F]ilter | [B]ack to Main Menu")
            cmd = input("Select Navigation Action: ").strip().lower()

            if cmd == 'n':
                if page < total_pages:
                    page += 1
                else:
                    print("   ℹ️ You are on the last page.")
            elif cmd == 'p':
                if page > 1:
                    page -= 1
                else:
                    print("   ℹ️ You are on the first page.")
            elif cmd == 's':
                sort_by = self.prompt_choice("Sort by field", ["deadline", "priority", "hours", "id"], default="deadline")
            elif cmd == 'b' or cmd == '':
                break

    def menu_update_status(self):
        task_id = self.prompt_int("Enter Task ID to update")
        task = self.service.get_task(task_id)
        if not task:
            print(f"❌ Task ID #{task_id} not found.")
            return

        print(f"\nUpdating Task #{task.task_id}: '{task.title}' (Current: {task.status})")
        new_status = self.prompt_choice("Select New Status", ["Pending", "In Progress", "Completed"])
        self.service.update_task(task_id, status=new_status)
        print(f"✅ Updated Task #{task_id} status to '{new_status}'.")

    def menu_search(self):
        query = self.prompt_string("Enter search term (title, category, priority, or status)")
        results = self.service.search_tasks(query)
        print(f"\n🔍 Search Results for '{query}' ({len(results)} found):")
        self.display_task_table(results, 1, 1, len(results))

    def menu_analytics(self):
        stats = self.service.get_summary_analytics()
        print("\n" + "=" * 55)
        print("    📊 EXECUTIVE STUDYSPRINT ANALYTICS & METRICS")
        print("=" * 55)
        print(f"  • Total Tasks:        {stats['total']}")
        print(f"  • Completed Tasks:    {stats['completed']} ({stats['completion_rate']}%)")
        print(f"  • Active In Progress: {stats['in_progress']}")
        print(f"  • Backlog Pending:    {stats['pending']}")
        print(f"  • Overdue Tasks:      {stats['overdue_count']} 🚨")
        print(f"  • Workload Hours:     {stats['completed_hours']}h completed / {stats['total_hours']}h total")
        print("-" * 55)

    def menu_export(self):
        print("\n📤 Export & Report Options")
        print("1. Export Audit Report (Markdown)")
        print("2. Export CSV Dataset")
        print("3. Generate Progress Visual Chart (PNG)")
        print("4. Export All Formats")
        opt = input("Choice (1-4): ").strip()

        if opt == "1":
            self.service.export_markdown_report()
            print("✅ Markdown report saved to 'study_report.md'.")
        elif opt == "2":
            self.service.export_csv()
            print("✅ CSV dataset saved to 'study_export.csv'.")
        elif opt == "3":
            if self.service.generate_chart():
                print("✅ Progress chart saved to 'study_progress_chart.png'.")
            else:
                print("❌ Failed to render progress chart.")
        elif opt == "4":
            self.service.export_markdown_report()
            self.service.export_csv()
            self.service.generate_chart()
            print("✅ All exports generated successfully!")

    def run(self):
        while True:
            self.print_banner()
            print(" 1. View & Manage Tasks (Paginated)")
            print(" 2. Add New Task")
            print(" 3. Update Task Status")
            print(" 4. Search Tasks")
            print(" 5. View Executive Analytics")
            print(" 6. Export Reports & Visual Dashboard")
            print(" 7. Delete Task")
            print(" 8. Exit")
            print("=" * 65)

            choice = input("Select Option (1-8): ").strip()
            if choice == "1":
                self.menu_list_tasks()
            elif choice == "2":
                self.menu_add_task()
            elif choice == "3":
                self.menu_update_status()
            elif choice == "4":
                self.menu_search()
            elif choice == "5":
                self.menu_analytics()
            elif choice == "6":
                self.menu_export()
            elif choice == "7":
                t_id = self.prompt_int("Enter Task ID to delete")
                if self.service.delete_task(t_id):
                    print(f"✅ Deleted Task #{t_id}.")
                else:
                    print(f"❌ Task ID #{t_id} not found.")
            elif choice == "8":
                print("\n👋 Thank you for using StudySprint Planner! Happy Studying!\n")
                break
            else:
                print("❌ Invalid option. Please select 1-8.")


def seed_demo_data(service: StudySprintService):
    """Seed dataset if empty to provide rich context."""
    if len(service.tasks) > 0:
        return
    
    logger.info("Seeding initial dataset with 35 realistic study sprint tasks...")
    sample_tasks = [
        ("Implement Binary Search Tree", "Computer Science", "High", "2026-11-20", 4.0, "Completed"),
        ("Write Literature Review Draft", "English", "Medium", "2026-11-25", 6.0, "In Progress"),
        ("Solve Multivariable Calculus Problem Set", "Mathematics", "High", "2026-11-18", 5.0, "Pending"),  # Overdue
        ("Prepare Physics Lab Report", "Physics", "High", "2026-11-22", 3.5, "In Progress"),
        ("Read Microeconomics Chapter 4-6", "Economics", "Low", "2026-11-30", 2.5, "Pending"),
        ("Database Normalization Quiz Prep", "Computer Science", "High", "2026-11-21", 3.0, "In Progress"),
        ("Organic Chemistry Reaction Mechanisms", "Chemistry", "High", "2026-11-17", 5.5, "Pending"),  # Overdue
        ("Statistics Linear Regression Homework", "Mathematics", "Medium", "2026-11-24", 2.0, "Completed"),
        ("History Essay on Industrial Revolution", "History", "Low", "2026-12-05", 4.5, "Pending"),
        ("Operating Systems Memory Management Notes", "Computer Science", "Medium", "2026-11-26", 3.0, "Completed"),
        ("Linear Algebra Eigenvalues Sheet", "Mathematics", "High", "2026-11-23", 4.0, "Completed"),
        ("Quantum Mechanics Wavefunction Practice", "Physics", "Medium", "2026-11-28", 3.5, "Pending"),
        ("Macroeconomics Fiscal Policy Analysis", "Economics", "Low", "2026-12-02", 2.0, "Completed"),
        ("Data Structures Graph Algorithms", "Computer Science", "High", "2026-11-22", 5.0, "In Progress"),
        ("Technical Writing Resume Workshop", "Career", "Low", "2026-11-29", 1.5, "Completed"),
        ("Cell Biology Mitosis & Meiosis Review", "Biology", "Medium", "2026-11-27", 3.0, "Pending"),
        ("French Conjugation Drill", "Languages", "Low", "2026-11-25", 1.0, "Completed"),
        ("Software Engineering Design Patterns", "Computer Science", "High", "2026-11-21", 4.5, "Completed"),
        ("Discrete Math Graph Theory Proofs", "Mathematics", "High", "2026-11-23", 4.0, "In Progress"),
        ("Electromagnetism Maxwell Equations", "Physics", "Medium", "2026-11-29", 3.5, "Pending"),
        ("Game Theory Nash Equilibrium Assignment", "Economics", "Medium", "2026-12-01", 3.0, "Completed"),
        ("AI Ethics Essay Draft", "Philosophy", "Low", "2026-12-04", 2.5, "Pending"),
        ("Computer Networks TCP/IP Protocol Analysis", "Computer Science", "High", "2026-11-24", 4.0, "In Progress"),
        ("Differential Equations Fourier Series", "Mathematics", "Medium", "2026-11-27", 3.5, "Completed"),
        ("Thermodynamics Entropy Calculations", "Physics", "High", "2026-11-25", 4.0, "Pending"),
        ("Corporate Finance Valuation Model", "Finance", "High", "2026-11-26", 5.0, "Completed"),
        ("Spanish Oral Presentation Outline", "Languages", "Medium", "2026-11-28", 2.0, "In Progress"),
        ("Cybersecurity Cryptography RSA Proof", "Computer Science", "High", "2026-11-22", 4.5, "Completed"),
        ("Abstract Algebra Group Theory Quiz", "Mathematics", "Medium", "2026-11-29", 3.0, "Pending"),
        ("Astrophysics Stellar Evolution Reading", "Physics", "Low", "2026-12-06", 2.5, "Completed"),
        ("Behavioral Economics Prospect Theory Paper", "Economics", "Medium", "2026-12-03", 3.5, "Pending"),
        ("Cloud Computing AWS Architecture Lab", "Computer Science", "High", "2026-11-25", 4.0, "Completed"),
        ("Real Analysis Metric Spaces Homework", "Mathematics", "High", "2026-11-26", 5.0, "In Progress"),
        ("Optics Interference & Diffraction Notes", "Physics", "Low", "2026-12-07", 2.0, "Completed"),
        ("International Trade Tariff Analysis", "Economics", "Low", "2026-12-08", 2.5, "Pending")
    ]

    for title, cat, prio, deadline, hours, status in sample_tasks:
        service.add_task(title, cat, prio, deadline, hours, status)


def main():
    service = StudySprintService()
    seed_demo_data(service)

    # Automatically generate default artifacts for immediate presentation
    service.export_markdown_report()
    service.export_csv()
    service.generate_chart()

    if "--batch" in sys.argv or "--non-interactive" in sys.argv:
        print("Running StudySprint Planner in non-interactive batch mode...")
        print("Batch processing finished.")
        return

    view = CLIView(service)
    view.run()


if __name__ == "__main__":
    main()
