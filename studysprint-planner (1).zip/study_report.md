# 📚 StudySprint Planner — Executive Progress & Audit Report
*Generated on 2026-11-19 17:38:14*

---

## 📊 Summary Analytics

| Metric | Value | Details |
| :--- | :--- | :--- |
| **Total Tasks** | `35` | Active Sprint Scope |
| **Completed Tasks** | `13` | `37.1%` Completion Rate |
| **In Progress** | `9` | Active Workstreams |
| **Pending** | `13` | Backlog Items |
| **Overdue Tasks** | `2` | ⚠️ Requires Immediate Focus |
| **Total Workload** | `114.0 hrs` | `35.5 hrs` Logged Completed |

---

## 🎯 Priority & Category Breakdown

### Priorities
- **High Priority**: 15 tasks (42.9%)
- **Medium Priority**: 12 tasks (34.3%)
- **Low Priority**: 8 tasks (22.9%)

### Subject Categories
- **Computer Science**: 10 tasks (28.6%)
- **Mathematics**: 6 tasks (17.1%)
- **Physics**: 5 tasks (14.3%)
- **Chemistry**: 4 tasks (11.4%)
- **Economics**: 3 tasks (8.6%)
- **History**: 2 tasks (5.7%)
- **Literature**: 2 tasks (5.7%)
- **Languages**: 2 tasks (5.7%)
- **Psychology**: 1 tasks (2.9%)

---

## 📝 Detailed Task Roster

| ID | Title | Category | Priority | Deadline | Hours | Status | Overdue |
|---|---|---|---|---|---|---|---|
| 13 | Probability & Statistics Hypothesis Testing | Mathematics | High | 2026-11-17 | 3.0 | In Progress | 🚨 YES |
| 4 | Organic Chemistry Reaction Mechanism Notes | Chemistry | High | 2026-11-18 | 3.5 | Pending | 🚨 YES |
| 9 | Python Data Cleaning with Pandas | Computer Science | High | 2026-11-19 | 2.5 | Completed | OK |
| 2 | Solve Multivariable Calculus Set #4 | Mathematics | High | 2026-11-20 | 3.0 | Completed | OK |
| 34 | Machine Learning Scikit-Learn Model Evaluation | Computer Science | High | 2026-11-20 | 4.0 | Completed | OK |
| 6 | Linear Algebra Eigenvalues & Eigenvectors | Mathematics | Medium | 2026-11-21 | 2.0 | Completed | OK |
| 26 | Operating Systems Process Synchronization | Computer Science | High | 2026-11-21 | 4.0 | Completed | OK |
| 3 | Read Quantum Mechanics Ch. 5-7 | Physics | Medium | 2026-11-22 | 2.5 | In Progress | OK |
| 23 | Algorithms Dynamic Programming Problems | Computer Science | High | 2026-11-22 | 5.0 | In Progress | OK |
| 12 | Database Normalization & SQL Queries | Computer Science | High | 2026-11-23 | 3.5 | Completed | OK |
| 7 | Prepare Presentation on Macroeconomics | Economics | Medium | 2026-11-24 | 4.0 | In Progress | OK |
| 18 | Differential Equations Laplace Transforms | Mathematics | High | 2026-11-24 | 4.0 | In Progress | OK |
| 1 | Implement Binary Search Tree Module | Computer Science | High | 2026-11-25 | 4.5 | Completed | OK |
| 17 | Thermodynamics Laws & Entropy Review | Physics | Medium | 2026-11-25 | 3.0 | Completed | OK |
| 29 | Cell Biology Signal Transduction Diagram | Chemistry | Medium | 2026-11-25 | 2.5 | In Progress | OK |
| 10 | Electromagnetism Problem Set #3 | Physics | High | 2026-11-26 | 4.0 | Pending | OK |
| 24 | Complex Analysis Residue Theorem Homework | Mathematics | High | 2026-11-26 | 3.5 | Pending | OK |
| 14 | Biochemistry Enzyme Kinetics Lab Report | Chemistry | Medium | 2026-11-27 | 5.0 | In Progress | OK |
| 25 | Special Relativity Time Dilation Calculations | Physics | Medium | 2026-11-27 | 2.5 | Completed | OK |
| 5 | Draft Technical Report on Distributed Systems | Computer Science | High | 2026-11-28 | 6.0 | In Progress | OK |
| 20 | Computer Networks TCP/IP Protocol Analysis | Computer Science | Medium | 2026-11-28 | 3.0 | Pending | OK |
| 32 | Vector Calculus Green's & Stokes' Theorem | Mathematics | High | 2026-11-28 | 3.5 | In Progress | OK |
| 15 | Neural Networks Forward/Backprop Coding | Computer Science | High | 2026-11-29 | 6.5 | Pending | OK |
| 19 | Spanish Grammar & Conjugation Practice | Languages | Low | 2026-11-29 | 1.5 | Completed | OK |
| 30 | Web Development React Component Sprint | Computer Science | Medium | 2026-11-29 | 4.5 | Pending | OK |
| 8 | Review World War II Historical Documents | History | Low | 2026-11-30 | 1.5 | Pending | OK |
| 21 | Spectroscopy Data Interpretation | Chemistry | Medium | 2026-11-30 | 2.5 | Pending | OK |
| 28 | French Vocabulary Anki Deck Flashcards | Languages | Low | 2026-11-30 | 1.0 | Completed | OK |
| 11 | Analyze Shakespeare Hamlet Act III | Literature | Low | 2026-12-01 | 2.0 | Completed | OK |
| 33 | Optics Wave Interference Lab Calculations | Physics | Medium | 2026-12-01 | 2.5 | Pending | OK |
| 22 | Cognitive Psychology Memory Models Notes | Psychology | Low | 2026-12-02 | 2.0 | Completed | OK |
| 16 | Microeconomics Market Structures Essay | Economics | Low | 2026-12-03 | 2.5 | Pending | OK |
| 27 | Game Theory Nash Equilibrium Assignment | Economics | Medium | 2026-12-04 | 3.0 | Pending | OK |
| 31 | Modern Philosophy Ethics Essay Draft | History | Low | 2026-12-05 | 3.0 | Pending | OK |
| 35 | Literary Criticism Postmodernism Paper | Literature | Low | 2026-12-06 | 3.0 | Pending | OK |
